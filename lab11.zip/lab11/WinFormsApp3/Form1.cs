using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace WinFormsApp3
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=SHASHI\\SQLEXPRESS;Initial Catalog=exam;Integrated Security=True;Encrypt=False");
        public Form1()
        {
            InitializeComponent();
            LoadList();
        }

        private void LoadList()
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from tbl_Designation", con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr[0].ToString());
                comboBox2.Items.Add(dr[1].ToString());
            }
            dr.Close();
            con.Close();
        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string query;
            if(comboBox2.SelectedIndex == -1) {
                query = "select * from tbl_EmployeeDetails";
            }
            else
            {
                query = $"select * from tbl_EmployeeDetails where IdDesignation='{comboBox2.SelectedIndex}'";
            }

            con.Open();
            SqlCommand cmd = new SqlCommand (query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            dr.Close();
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = $"insert into tbl_EmployeeDetails(IdEmployee, EmployeeName, ContactNumber, IdDesignation, IdReportingTo) values('{textBox1.Text}', '{textBox2.Text}', '{textBox3.Text}', '{comboBox1.Text}', '{textBox5.Text}')";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data Inserted Successfully");
            con.Close();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox5.Clear();
        }
    }
}
