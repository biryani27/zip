using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace lab12
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=SHASHI\\SQLEXPRESS;Initial Catalog=exam;Integrated Security=True;Encrypt=False");
        SqlDataAdapter da;
        DataTable dt = new DataTable();
        public Form1()
        {
            InitializeComponent();
            LoadData();
            SetupDataGridView();
            LoadLecturers();
        }

        public void LoadData()
        {
            dt.Clear();
            con.Open();
            da = new SqlDataAdapter("select SubjectName from tbl_Subjects", con);
            da.Fill(dt);
            dataGridView1.DataSource = dt.DefaultView;
            con.Close();
        }

        private void SetupDataGridView()
        {
            DataGridViewCheckBoxColumn cb = new DataGridViewCheckBoxColumn();
            cb.Name = "cbc";
            dataGridView1.Columns.Insert(0, cb);
        }

        private void LoadLecturers()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select LecturerName from tbl_Lecturers", con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr["LecturerName"].ToString());
                comboBox2.Items.Add(dr["LecturerName"].ToString());
            }

            dr.Close();
            con.Close();
        }

        private void InsertLecturer(string name, string title)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand($"insert into tbl_Lecturers values('{name}', '{title}')", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Lecturer Data Added Successfully");
        }

        private void InsertSubject(string name, string title)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand($"insert into tbl_Subjects values ('{name}', '{title}')", con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Subject Details added successfully");
        }

        private void InsertLecturerSubject(string lecturerName, object SubjectName)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand($"insert into tbl_LecturerSubjects values('{lecturerName}', '{SubjectName}')", con);
             cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Lecturer Subjects Added Sucessfully");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertSubject(textBox1.Text, textBox2.Text);
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            InsertLecturer(textBox3.Text, textBox4.Text);
            textBox3.Text = "";
            textBox4.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                bool isChecked = Convert.ToBoolean(row.Cells["cbc"].Value);
                if (isChecked)
                {
                    InsertLecturerSubject(comboBox1.SelectedItem.ToString(), row.Cells[1].Value);
                }
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt1 = new DataTable();
            con.Open();
            da = new SqlDataAdapter($"select * from tbl_LecturerSubjects where LecturerName='{comboBox2.SelectedItem}'", con);
            da.Fill(dt1);
            dataGridView1.DataSource = dt1.DefaultView;
            con.Close();

        }
    }
}
